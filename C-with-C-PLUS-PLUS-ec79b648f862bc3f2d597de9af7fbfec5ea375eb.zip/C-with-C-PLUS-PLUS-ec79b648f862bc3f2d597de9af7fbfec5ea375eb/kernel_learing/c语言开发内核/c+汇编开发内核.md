##### c语言汇编开发内核

------

c语言默认的运行环境就是保护模式，所以只有进入保护模式c语言才可以介入开发流程

------

调用流程：
源代码包含两个文件foo.asm和bar.c
foo.asm中_start 入口函数，之后调用bar.c函数中的bar_func函数
之后进入c代码，c中在调用汇编的foo_print函数。

------

foo.asm:

```assembly
extern bar_func;声明外部函数

[section .data]
arg1  dd 3
arg2  dd 4

[section .text]
global _start
global foo_print ;声明出来这样c语言才能调用到这个接口

_start:
mov   eax, dword[arg1] ;读取arg1的4字节地址的内容(3)放到eax(硬件的一个32位寄存器)
push  eax ;压入堆栈
mov   eax, dword [arg2]
push  eax
call  bar_func ;压入堆栈后bar_func的第一个参数是arg2(因为arg2是后压入堆栈的)
add   esp, 8 ;调整esp指针+8 相当于清除上面的8个字节

;这三行是linux的系统调用，eax表示的返回值，0x80是调用号，ebx是设置的参数
;目的是告诉系统这个模块已经执行完毕了，让linux把这个可执行程序卸载，清理堆栈
mov   ebx,0   
mov   eax, 1
int   0x80

;给c去调用的函数，后三行也是一个系统调用，目的是打印一个字符串
foo_print: 
mov   edx, [esp + 8] ;edx存储要打印的长度
mov   ecx, [esp + 4] ;ecx存储要打印的内容
mov   ebx, 1
mov   eax, 4
int   0x80
ret


```

```c

extern void foo_print(char* a, int len);

int  bar_func(int a, int b) {
    if (a > b) {
       foo_print("the 1st one\n", 13);
    } else {
       foo_print("the 2nd one\n", 13);
    }

    return 0;
}


```

上面两个文件的编译，需要在Linux系统上进行，我用的是ubuntu,先编译foo.asm: 
 nasm -f elf32 -o foo.o foo.asm

然后编译bar.c 
 gcc -m32 -c -o bar.o bar.c

接下来就可以将两个模块连接在一起了： 
 ld -m elf_i386 -o foobar foo.o bar.o

于是在目录下便会生成一个可执行文件 foobar, 通过下面指令可将生成的可执行文件加载执行：

./foobar

------

但在这样编译出来的是ELF格式的文件（可以用readelf命令查看），内核编译成ELF格式是不能直接加载到内存运行的，所以需要把C语言反汇编成汇编，在将反汇编的代码放入汇编文件中，编译单个asm文件成2进制代码。

1.  先写好汇编代码和对应的C代码。
2.   用以下命令编译C代码模块，以便后面反汇编：gcc -m32 -fno-asynchronous-unwind-tables -s -c -o bar.o bar.c  （去掉符号表不然编译出来的汇编很复杂）
3. 下载一个好用的反汇编工具objconv，通过如下命令下载：git clone https://github.com/vertis/objconv.git 
4. 下载后进入objconv目录，编译该工具，运行下面的命令：g++ -o objconv -O2 src/*cpp ， -O2中的圆圈是大写字母O.  
5. 用objconv 反汇编C语言生成的目标文件bar.o,命令如下：objconv -fnasm bar.o -o bar.asm,于是目录下便有一个反汇编文件bar.asm  
6.  打开foo.asm, 将里面的_start, 修改成main, 这一步在后面我们编译系统内核时可以不用，现在这么做，主要是想编译成linux可执行文件  
7. 在foo.asm末尾，通过语句：%include “bar.asm” 将第五步反汇编的C模块代码引入foo.asm。  
8.  运行命令编译nasm -f elf32 foo.asm, 执行这一步后，目录上会出现foo.o二进制文件  
9.  执行命令：gcc -m32 foo.o -o foo. 这一步将foo.o与系统模块连接成可执行文件，编译系统内核时，这一步就不需要。  10. 运行结果：./foo, 就可以看到运行结果了。 












