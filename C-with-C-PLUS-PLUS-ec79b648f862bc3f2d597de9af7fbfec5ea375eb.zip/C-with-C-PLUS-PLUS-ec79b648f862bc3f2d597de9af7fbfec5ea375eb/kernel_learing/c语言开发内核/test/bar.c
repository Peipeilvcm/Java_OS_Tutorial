extern void foo_print(char *a, int len)

int bar_func(int a, int b)
{
    if(a>b)
    {
        foo_print("the 1st one\n");
    }
    else
    {
        foo_print("the 2nd one\n");
    }

    return 0;
}