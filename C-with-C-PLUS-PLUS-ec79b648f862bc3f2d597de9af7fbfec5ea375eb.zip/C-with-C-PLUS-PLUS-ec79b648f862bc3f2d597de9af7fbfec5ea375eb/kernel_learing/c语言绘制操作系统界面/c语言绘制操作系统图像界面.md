##### c语言绘制操作系统图像界面

------

要想由字符模式转入图形模式，我们需要操作硬件，特别是向显卡发送命令，让其进入图形显示模式，就如同前面我们所做的，要操作硬件，一般需要使用BIOS调用，以下几行就是打开VGA显卡色彩功能的代码：

```nasm
mov  al, 0x13h ;VGA图形模式, 320 * 200 * 8位彩色模式，调色板模式
mov  ah, 0x00
int  0x10
```

其中al 的值决定了要设置显卡的色彩模式，下面是一些常用的模式设置： 

1. 0x03, 16色字符模式 
   2. 0x12, VGA图形模式, 640 * 480 * 4位彩色模式，独特的4面存储模式 
      3. 0x13, VGA图形模式, 320 * 200 * 8位彩色模式，调色板模式 
         4. 0x6a, 扩展VGA图形模式， 800 * 600 * 4彩色模式

我们采用的是0x13模式，其中320* 200 *8 中，最后的数值8表示的是色彩值得位数，也就是我们可以用8位数值表示色彩，总共可以显示256种色彩。

系统显存的地址是0x000a0000，当我们执行上面几句代码后，望显存地址写入数据，那么屏幕就会出现相应的变化了。

------

kernel.asm

```assembly
%include "pm.inc"

org   0x9000

jmp   LABEL_BEGIN

[SECTION .gdt]
 ;                                  段基址          段界限                属性
LABEL_GDT:          Descriptor        0,            0,                   0  
LABEL_DESC_CODE32:  Descriptor        0,      SegCode32Len - 1,       DA_C + DA_32
LABEL_DESC_VIDEO:   Descriptor        0B8000h,         0ffffh,            DA_DRW
;为了c语言的运行，给GDT（用来告诉cpu怎么使用内存的）的描述符写入4G的可读写内存
LABEL_DESC_VRAM:    Descriptor        0,         0ffffffffh,            DA_DRW
;设置512字节的堆栈给c语言堆栈使用不然c语言无法进行函数调用
LABEL_DESC_STACK:   Descriptor        0,             TopOfStack,        DA_DRWA+DA_32

GdtLen     equ    $ - LABEL_GDT
GdtPtr     dw     GdtLen - 1
           dd     0

SelectorCode32    equ   LABEL_DESC_CODE32 -  LABEL_GDT
SelectorVideo     equ   LABEL_DESC_VIDEO  -  LABEL_GDT
SelectorStack     equ   LABEL_DESC_STACK  -  LABEL_GDT
SelectorVram      equ   LABEL_DESC_VRAM   -  LABEL_GDT


[SECTION  .s16]
[BITS  16]
LABEL_BEGIN:
     mov   ax, cs
     mov   ds, ax
     mov   es, ax
     mov   ss, ax
     mov   sp, 0100h

     mov   al, 0x13
     mov   ah, 0
     int   0x10

     xor   eax, eax
     mov   ax,  cs
     shl   eax, 4
     add   eax, LABEL_SEG_CODE32
     mov   word [LABEL_DESC_CODE32 + 2], ax
     shr   eax, 16
     mov   byte [LABEL_DESC_CODE32 + 4], al
     mov   byte [LABEL_DESC_CODE32 + 7], ah

     ;set stack for C language
     xor   eax, eax
     mov   ax,  cs
     shl   eax, 4
     add   eax, LABEL_STACK
     mov   word [LABEL_DESC_STACK + 2], ax
     shr   eax, 16
     mov   byte [LABEL_DESC_STACK + 4], al
     mov   byte [LABEL_DESC_STACK + 7], ah

    ;设置好保护模式
     xor   eax, eax
     mov   ax, ds
     shl   eax, 4
     add   eax,  LABEL_GDT
     mov   dword  [GdtPtr + 2], eax

     lgdt  [GdtPtr]

     cli   ;关中断

     in    al,  92h
     or    al,  00000010b
     out   92h, al

     mov   eax, cr0
     or    eax , 1
     mov   cr0, eax

     jmp   dword  SelectorCode32: 0

     [SECTION .s32]
     [BITS  32]
     LABEL_SEG_CODE32:
     ;initialize stack for c code
     mov  ax, SelectorStack
     mov  ss, ax ;ss指向堆栈的描述符
     mov  esp, TopOfStack ;指向堆栈的栈顶，每次压入堆栈指针减2

     mov  ax, SelectorVram
     mov  ds,  ax

C_CODE_ENTRY:
     %include "write_vga.asm"


     io_hlt:  ;void io_hlt(void);
      HLT ;使整个计算机硬件进入休眠状态
      RET

SegCode32Len   equ  $ - LABEL_SEG_CODE32

[SECTION .gs]
ALIGN 32
[BITS 32]
LABEL_STACK:;初始化栈的512个字节
times 512  db 0
TopOfStack  equ  $ - LABEL_STACK

```



