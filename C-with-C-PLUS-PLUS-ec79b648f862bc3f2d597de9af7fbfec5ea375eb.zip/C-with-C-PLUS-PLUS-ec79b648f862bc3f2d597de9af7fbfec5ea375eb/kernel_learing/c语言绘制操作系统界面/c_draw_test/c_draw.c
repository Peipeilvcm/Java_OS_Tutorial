void CMain(void)
{
    int i;
    char *p = 0;

    for(i=0xa0000;i<=0xaffff;i++) //VGA的显存地址
    {
        p = i;
        *p = i & 0x0f; //将i的后四位作为像素颜色写入显存
    }

    for(;;)
    {
        io_hlt();
    }

}