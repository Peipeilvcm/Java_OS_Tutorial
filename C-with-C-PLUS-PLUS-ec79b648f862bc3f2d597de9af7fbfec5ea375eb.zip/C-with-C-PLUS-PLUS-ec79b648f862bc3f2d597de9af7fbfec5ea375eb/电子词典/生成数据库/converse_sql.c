#include "usual.h"

#define MAXSIZE 4096

int main(int argc ,char **argv)
{
    sqlite3 *db;
    int ret;
    char sql[MAXSIZE] = "\0";
    char *errmsg = NULL;
    int i = 0;

    //step1:打开数据库
    ret = sqlite3_open("./disc_word.db",&db);
   if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_open : %s\n", sqlite3_errmsg(db));
		return -1;
	}

    //step 2:建表
	sprintf(sql, "create table %s (id integer, word text, explanation text);", "disc");
	ret = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "create table : %s\n", sqlite3_errmsg(db));
		fprintf(stderr, "create table : %s\n", errmsg);
		return -1;
	}

    //从文件中读取数据
    char buf[MAXSIZE] = "\0";
    FILE *fp;
    fp = fopen("./dict.txt","rt+");
    char *p,*q;
    
    while(fgets(buf,sizeof(buf),fp) != NULL)
    {
        // fgets(buf,sizeof(buf),fp); //每读一行放到buf
        p = buf;
        while(*p != ' ')
        {
            p++;
        }

      //  printf("===================\n");

        q = p;//p跑到单词的最后

        while(*q  == ' ')
        {
            q++;
        }       //q跑到解释的最前

        buf[strlen(buf)-1] = '\0';//单词长度
        *p = '\0';
        
        sprintf(sql, "insert into disc(id, word, explanation) values (\"%d\", \"%s\", \"%s\");",i++,buf,q);
        ret = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(SQLITE_OK != ret)
        {
            fprintf(stderr, "insert table : %s\n", sqlite3_errmsg(db));
            fprintf(stderr, "insert table : %s\n", errmsg);
            return -1;
        }
        printf("%s\n",sql);
        memset(buf,'\0',sizeof(buf));
        memset(sql,'\0',sizeof(sql));
    
    }
    fclose(fp);
    printf("write success\n");


    //last step: 关闭数据库
	ret = sqlite3_close(db);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_close : %s\n", sqlite3_errmsg(db));
		return -1;
	}


    return 0;
}