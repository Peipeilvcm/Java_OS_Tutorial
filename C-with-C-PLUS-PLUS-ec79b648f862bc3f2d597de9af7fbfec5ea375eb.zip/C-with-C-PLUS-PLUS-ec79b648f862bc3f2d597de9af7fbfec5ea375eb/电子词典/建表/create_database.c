  #include "usual.h"

	int main()
	{
	sqlite3 *db;
	int ret;
	char sql[1024] = "\0";
	char *errmsg = NULL;
  //step1:打开数据库
    ret = sqlite3_open("./disc_usr.db",&db);
   if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_open : %s\n", sqlite3_errmsg(db));
		return -1;
	}

    //step 2:建表
	sprintf(sql, "create table %s (name text, num integer);", "usr");
	ret = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "create table : %s\n", sqlite3_errmsg(db));
		fprintf(stderr, "create table : %s\n", errmsg);
		return -1;
	}

	//插入数据
	 sprintf(sql, "insert into usr(name, num) values (\"%s\", \"%d\");","xiaoming",123);
        ret = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(SQLITE_OK != ret)
        {
            fprintf(stderr, "insert table : %s\n", sqlite3_errmsg(db));
            fprintf(stderr, "insert table : %s\n", errmsg);
            return -1;
        }
   
	      printf("%s\n",sql);
				return 0;
	}