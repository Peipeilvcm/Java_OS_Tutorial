#include "usual.h"
#include "func.h"



int main()
{
    memset(&seraddr, 0, sizeof(seraddr));
	seraddr.sin_family = AF_INET;
	seraddr.sin_port = htons(8888);
	seraddr.sin_addr.s_addr = inet_addr("0.0.0.0");
    int n;


//****************************************************************************************
   
  while(1)
  {
	

    printf("**************************请输入操作的选项******************************\n");
     printf("**************************1.登陆******************************\n");
     printf("**************************2.注册******************************\n");
     printf("*************************3.退出*******************************\n");

    scanf("%d",&n);

    switch(n)
    {
        case 1: //登陆操作
		online();

         case 2:
            //注册操作*************************************************
            //向disc_usr.db中写入注册信息
            //int func_registered()
            func_registered();
            break;
        case 3:
            //退出
            return -1;
        default:printf("error\n");

    }
	
		
	
	

	return 0;
  }
}