#include "usual.h"
#include "func.h"


int net_init() //网络连接的初始化
{
	int connfd;
	int ret;
	connfd = socket(AF_INET, SOCK_STREAM, 0);
	if(-1 == connfd)
	{
		perror("socket failed");
		exit(-1);
	}
	ret = connect(connfd, (struct sockaddr *)&seraddr, sizeof(seraddr));
	if(-1 == ret)
	{
		perror("connect failed");
		exit(-1);
	}
	printf("connect successfully\n");
	return connfd;
}



int online_select()//登陆后的选择操作
{
    sqlite3 *db;
	int ret;

   
	//step 1:打开数据库 
	ret = sqlite3_open("./disc_word.db", &db);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_open : %s\n", sqlite3_errmsg(db));
		return -1;
	}
    int i;
    char x[MAXSIZE];
    char sql[1024] = "\0";
	char *errmsg = NULL;
	char **result = NULL;
    int nrow, ncolumn;
	int j;
    int choice;
COM:
    printf("请输入你的操作：\n");
    printf("1.查询单词\n");
    printf("2.查询历史\n");
    printf("3.退出\n");
    
    scanf("%d",&i);
    switch(i)
    {
        case 1:
            //执行查询单词的操作 从数据库disc_word中找到并匹配
             //step 2:从数据库中查询数据进行对比
    
        while(1)
        {       
            printf("请输入要查询的单词\n");
            
                scanf("%s",x);
                printf("输入的单词是%s\n",x);
           
           sprintf(sql, "select * from disc;");
           ret = sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg);
	      if(SQLITE_OK != ret)
          {
		     fprintf(stderr, "select: %s\n", errmsg);
		     return -1;
	      }
          for(j = 0; j < (nrow+1)*ncolumn; j++)
          {
             if(0 == strcmp(x,result[j]))
             {
               printf("解释是 %s\n", result[j+1]);
            //    printf("继续查输入1,停止输入0\n");
            //    scanf("%n",&choice);
            //    if(1 == choice)
            //         continue;
            //    else
            //        break;


                

            
             }
	      }
	     sqlite3_free_table(result);
        }


            
        case 2:
            //查询历史
            printf("\n"); 
            printf("\n");
            printf("\t*        * * * *     *       *     * * * * \n");
            printf("\t*       *       *    *       *    *       *\n"); 
            printf("\t*      *         *   *       *   * * * * * *\n"); 
            printf("\t*      *         *   *       *   *\n"); 
            printf("\t*       *       *     *     *     * \n");
            printf("\t*******  * * * *        * *        * * * *\n");
            getchar();
            goto COM;
            





          
        case 3:
            //退出
            return -1;
        default:printf("error\n");

    }
    return 0;

}

int online() //正在登陆的操作
{
    PRO command, message;//command为请求，message为接收服务器的消息
    //step1:连接服务器
    int connfd, fd;
	int ret;
    memset(&command, '\0', sizeof(command));
	memset(&message, '\0', sizeof(message));
	connfd = net_init(seraddr);//连接上了服务器
    //向服务器发送要求登陆的请求
    
    printf("请输入姓名：\n");
    scanf("%s",command.name);
   // fgets(command.name,sizeof(command.name),stdin);
     printf("请输入密码：\n");
     scanf("%s",command.num);
     //fgets(command.num,sizeof(command.num),stdin);
    
   printf("name is %s\t num is %s\n",command.name,command.num);
	command.control = 0; //登陆操作
    //向服务器发送数据
    ret = send(connfd, &command, sizeof(command), 0);
	if(-1 == ret)
	{
		perror("send failed");
		close(connfd);
		return -1;
	}

    printf("send name+num success\n");
    //服务器进行姓名和密码的对比，成功的化返回mseeage.content = "success"

    //从服务器接收数据
    ret = recv(connfd, &message, sizeof(message), 0);
	if(-1 == ret)
	{
		perror("recv failed");
		close(connfd);
		return -1;
	}

    printf("message.control = %d\n",message.control);

    printf("start entering disc....\n");

    if(0 == strncmp("success", message.content, 7))
	{
        online_select();
	}
    else
    {
        close(connfd);
		return -1 ;
    }

   

}
//*************************************************************************************
#if 0
int search_from_disc_usr(char name,int num)
{
      sqlite3 *db;
	int ret;
	char sql[1024] = "\0";
	char *errmsg = NULL;
	char **result = NULL;
	int nrow, ncolumn;
	int i;
   
	//step 1:打开数据库 
	ret = sqlite3_open("./disc_usr.db", &db);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_open : %s\n", sqlite3_errmsg(db));
		return -1;
	}

     //step 2:从数据库中查询数据进行对比
           sprintf(sql, "select * from usr;");
           ret = sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg);
	      if(SQLITE_OK != ret)
          {
		     fprintf(stderr, "select: %s\n", errmsg);
		     return -1;
	      }
          for(i = 0; i < (nrow+1)*ncolumn; i++)
          {
             if(name == result[i]&& num == result[i+1])
             {
                 printf("登陆成功\n");
                 strcpy(message.content, "success");
		        send(connfd, &message, sizeof(message), 0);
             }
	      }
	     sqlite3_free_table(result);
}

//*************************************************************************************
#endif


int func_registered()
{
     //step1:连接服务器
    int connfd, fd;
	int ret;

	connfd = net_init(seraddr);//连接上了服务器
    //向服务器发送要求登陆的请求
    PRO command, message;//command为请求，message为接收服务器的消息
    printf("开始注册：\n");
    printf("注册的姓名:\n");
    scanf("%s",command.name);
    printf("注册的密码：\n");
    scanf("%s",command.num);

    command.control = 1;

    //向服务器发送command
    ret = send(connfd, &command, sizeof(command), 0);
	if(-1 == ret)
	{
		perror("send failed");
		close(connfd);
		return -1;
	}

    //接收成功信号
    ret = recv(connfd, &message, sizeof(message), 0);
	if(-1 == ret)
	{
		perror("recv failed");
		close(connfd);
		return -1;
	}

    if(0 == strncmp("success", message.content, 7))
	{
        printf("注册成功\n");
	}


 
        
    return 0;
}


