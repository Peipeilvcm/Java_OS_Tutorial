#ifndef H_FILE2
#define H_FILE2

#include "usual.h"

#define MAXSIZE 1024
#define BUFSIZE 1024


typedef struct{
	char source; //来源 c, s
	char dest;   //目的  s, c
	int control;  //控制位 d, z, 登陆，注册
	char name[BUFSIZE]; //名字
    char num[BUFSIZE];//密码
    char content[BUFSIZE];
}PRO;


struct sockaddr_in seraddr;





int online();
int online_select();//登陆后的选择操作
int func_registered();//注册操作


#endif