#include "usual.h"
#include "func.h"
// #define BUFSIZE 1024
// typedef struct{
// 	char source; //来源 c, s
// 	char dest;   //目的  s, c
// 	char control;  //控制位 d, z, 登陆，注册
// 	char name[BUFSIZE]; //名字
//     char num[BUFSIZE];//密码
//     char content[BUFSIZE];
// }PRO;

//客户端的函数调用
#if 0  
int net_init(int connfd,struct sockaddr_in seraddr) //网络连接的初始化
{
	int connfd;
	int ret;
	connfd = socket(AF_INET, SOCK_STREAM, 0);
	if(-1 == connfd)
	{
		perror("socket failed");
		exit(-1);
	}
	ret = connect(connfd, (struct sockaddr *)&seraddr, sizeof(seraddr));
	if(-1 == ret)
	{
		perror("connect failed");
		exit(-1);
	}
	printf("connect successfully\n");
	return connfd;
}



int online_select()//登陆后的选择操作
{
      sqlite3 *db;
	int ret;

   
	//step 1:打开数据库 
	ret = sqlite3_open("./disc_usr.db", &db);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_open : %s\n", sqlite3_errmsg(db));
		return -1;
	}
    int i;
    char x[1024];
    char sql[1024] = "\0";
	char *errmsg = NULL;
	char **result = NULL;
    int nrow, ncolumn;
	int j;
    int choice;

    printf("请输入你的操作：\n");
    printf("1.查询单词\n");
    printf("2.查询历史\n");
    printf("3.退出\n");

    scanf("%d",i);
    switch(i)
    {
        case 1:
            //执行查询单词的操作 从数据库disc_word中找到并匹配
             //step 2:从数据库中查询数据进行对比
 COM:        
            printf("请输入要查询的单词\n");
            scanf("%s",x);
           sprintf(sql, "select * from disc;");
           ret = sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg);
	      if(SQLITE_OK != ret)
          {
		     fprintf(stderr, "select: %s\n", errmsg);
		     return -1;
	      }
          for(j = 0; j < (nrow+1)*ncolumn; j++)
          {
             if(x == result[j])
             {
               printf("解释是 %s\n", result[j+1]);
               printf("继续查输入1,停止输入n");
               scanf("%d",choice);
               if(1 == choice)
                    goto COM;
               else
                    return -1;


                break;

             }
	      }
	     sqlite3_free_table(result);

            break;
        case 2:
            //查询历史


            
           return -1;
        case 3:
            //退出
            return -1;
        default:printf("error\n");

    }
    return 0;
}
//*******************************************************************
int online() //正在登陆的操作
{
    
    //step1:连接服务器
    int connfd, fd;
	int ret;

	connfd = net_init();//连接上了服务器
    //向服务器发送要求登陆的请求
    PRO command, message;//command为请求，message为接收服务器的消息
    printf("请输入姓名：\n");
    scanf("%s",command.name);
     printf("请输入密码：\n");
     scanf("%d",command.num);
    memset(&command, '\0', sizeof(command));
	memset(&message, '\0', sizeof(message));
    command.source = 'c';//从client发出
	command.dest = 's'; //server接收
	command.control = 'd'; //登陆操作
    //向服务器发送数据
    ret = send(connfd, &command, sizeof(command), 0);
	if(-1 == ret)
	{
		perror("send failed");
		close(connfd);
		return -1;
	}

    //服务器进行姓名和密码的对比，成功的化返回mseeage.content = "success"

    //从服务器接收数据
    ret = recv(connfd, &message, sizeof(message), 0);
	if(-1 == ret)
	{
		perror("recv failed");
		close(connfd);
		return ;
	}

    if(0 == strncmp("success", message.content, 7))
	{
        online_select();
	}
    else
    {
        close(connfd);
		return -1 ;
    }

   

}

#endif
//*****************************服务器的函数调用********************************************************
int search_from_disc_usr(int connfd,char *name,char *num)
{
      sqlite3 *db;
	int ret;
	char sql[1024] = "\0";
	char *errmsg = NULL;
	char **result = NULL;
	int nrow, ncolumn;
	int i;

    PRO message;
     
	//step 1:打开数据库 
	ret = sqlite3_open("./disc_usr.db", &db);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_open : %s\n", sqlite3_errmsg(db));
		return -1;
	}
 
     //step 2:从数据库中查询数据进行对比
           sprintf(sql, "select * from usr;");
           ret = sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg);
	      if(SQLITE_OK != ret)
          {
		     fprintf(stderr, "select: %s\n", errmsg);
		     return -1;
	      }
          for(i = 0; i < (nrow+1)*ncolumn; i++)
          {
            // printf("%-8s\t", result[i]);
		    //  if(((i+1) % ncolumn) == 0)
			//     printf("\n");
             if(!strcmp(name,result[i]) && !strcmp(num,result[i+1]) )
             {
                 printf("登陆成功\n");
                 strcpy(message.content, "success");
		        send(connfd, &message, sizeof(message), 0);
             }
	      }
	     sqlite3_free_table(result);
}

#if 0
//********客户端*****************************************************************************
int func_registered(sqlite3 *db)
{
    char *sql;
    char *errmsg = NULL;
    char name[1024];
    int num;
    int ret;
    printf("现在执行注册：。。。\n");
    printf("请输入姓名：");
    scanf("%s",name);
    printf("请输入密码：");
    scanf("%d",num);

    sprintf(sql, "insert into usr(name, num) values (\"%s\", \"%d\");",name,num);
        ret = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(SQLITE_OK != ret)
        {
            fprintf(stderr, "insert table : %s\n", sqlite3_errmsg(db));
            fprintf(stderr, "insert table : %s\n", errmsg);
            return -1;
        }
        
    return 0;
}

#endif


int into_disc_usr(int connfd,char *name,char *num)
{
     sqlite3 *db;
	int ret;
	char sql[1024] = "\0";
	char *errmsg = NULL;
	char **result = NULL;
	int nrow, ncolumn;
	int i;
    PRO message;
    //step 1:打开数据库 
	ret = sqlite3_open("./disc_usr.db", &db);
	if(SQLITE_OK != ret)
    {
		fprintf(stderr, "sqlite3_open : %s\n", sqlite3_errmsg(db));
		return -1;
	}

    sprintf(sql, "insert into usr(name, num) values (\"%s\", \"%s\");",name,num);
        ret = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(SQLITE_OK != ret)
        {
            fprintf(stderr, "insert table : %s\n", sqlite3_errmsg(db));
            fprintf(stderr, "insert table : %s\n", errmsg);
            return -1;
        }

        strcpy(message.content, "success");
		send(connfd, &message, sizeof(message), 0);


}