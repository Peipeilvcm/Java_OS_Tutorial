#ifndef H_FILE1
#define H_FILE1
#include "usual.h"

#define BUFSIZE 1024
typedef struct{
	char source; //来源 c, s
	char dest;   //目的  s, c
	int  control;  //控制位 0, 1, 登陆，注
	char name[BUFSIZE]; //名字
    char num[BUFSIZE];//密码
    char content[BUFSIZE];
}PRO;

int search_from_disc_usr(int connfd,char *name,char *num);
int into_disc_usr(int connfd,char *name,char *num);

#endif