#include "usual.h"
#include "func.h"
#define BUFSIZE 1024

PRO command;
struct sockaddr_in seraddr, cliaddr;
socklen_t addrlen = sizeof(struct sockaddr);

// int search_from_disc_usr(char name,int num);
// int into_disc_usr(char name,int num);
int listenfd, connfd;

int main()
{
	int ret;

	//step 1: socket 创建socket 套接字
	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if(-1 == listenfd)
	{
		perror("socket failed");
		return -1;
	}
	//step 2: bind 绑定地址信息和端口号
	memset(&seraddr, 0, sizeof(seraddr));
	seraddr.sin_family = AF_INET;
	seraddr.sin_port = htons(8888);
	seraddr.sin_addr.s_addr = inet_addr("0.0.0.0");

	ret = bind(listenfd, (struct sockaddr *)&seraddr, sizeof(seraddr));
	if(-1 == ret)
	{
		perror("bind failed");
		return -1;
	}

	//step 3: listen 监听连接请求
	ret = listen(listenfd, 5);
	if(-1 == ret)
	{
		perror("listen failed");
		return -1;
	}
	while(1)
	{
	//step 4: accept 接受客户端请求，返回一个用于读写的套接字描述父
		connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &addrlen);
		if(-1 == connfd)
		{
			perror("accept failed");
			return -1;
		}
		printf("connect from %s port %d\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
		printf("accept success\n");

		ret = recv(connfd, &command, sizeof(command), 0);
		if(-1 == ret)
		{
			close(connfd);
			continue;
		}
		
		printf("recv name+num success\n");
		
		printf("command.control=%d\n",command.control);
		printf("name=%s\t num=%s\n",command.name,command.num);
		switch(command.control)
		{
		case 0:
			 printf("==========");
			search_from_disc_usr(connfd,command.name,command.num);
		case 1:
			into_disc_usr(connfd,command.name,command.num);continue;
		
		}

		close(connfd);
	}
	close(listenfd);
	return 0;
}
