#include <iostream>
#include "car.h"

using namespace::std;


int main()
{
    Car a;
    cout << sizeof(a) << endl;//函数定义是不占用内存的（在栈中）
 
    a.SetProperty(100,200);
    a.run();
    a.stop();

    return 0;
}