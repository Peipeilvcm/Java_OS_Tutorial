#include <iostream>
#include "car.h"

using namespace::std;

///* 类的实现*/
void Car::run()
{
    std::cout << "car run" << '\n';
}

void Car::stop()
{
    std::cout << "car stop" << '\n';
}

void Car::SetProperty(int price,int carNum)
{
    m_price = price;
    m_carNum = carNum;
}