#include <iostream>
using namespace::std;

class X;//前置声明类X

class Y
{
    public:
        void f(X *);//输入参数是一个X类型的指针
     //   void b(X); //* X是不能直接传进来的，传进来的只能是X的一个引用或者指针（因为X还没有被完全定义）
    private:
        X* pX;
};

// void Y::b(X a)
// {

// }

class X
{
    public:
        void initialize();
        friend void g(X *,int);// 全局友元函数
        friend void Y::f(X *);//类成员的友元
        friend class Z; //整个类都是友元
        friend void h();
    private:
        int i;
};

void X::initialize()
{
    i = 0;
}

void g(X *x,int i) //*g是X的友元函数，所以全局函数g可以访问X的成员i
{
    x->i = i;
}

void Y::f(X *x) //* Y的成员函数也可以访问X的成员i
{
    x->i = 47;
}

class Z
{
    public:
        void initialize();
        void g(X *x);
    private:
        int j;
};

void Z::initialize()
{
    j = 99;
}

void Z::g(X *x) //*这个类的所有成员函数都可以访问X的成员
{
    x->i += j;
}

int main()
{
    X x;
    Z z;
    z.g(&x);
    return 0;
}