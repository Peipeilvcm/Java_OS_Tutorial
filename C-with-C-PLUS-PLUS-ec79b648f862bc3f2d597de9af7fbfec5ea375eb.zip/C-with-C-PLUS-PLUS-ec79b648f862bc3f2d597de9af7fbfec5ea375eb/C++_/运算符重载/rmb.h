#ifndef _RMB_H
#define _RMB_H

typedef unsigned int uint;

#include <iostream>
using namespace::std;

class RMB
{
    //*友元函数重载运算符
    friend RMB operator+(const RMB&, const RMB&);//采用const引用代替值传递表示不会去修改RMB本身的参数
    friend bool operator>(const RMB&,const RMB&);

    public:
        RMB(uint y,uint jf);
        ~RMB();

        void display() const
        {
            cout << "RMB:" << yuan << "." << jf <<endl; 
        }
    
    private:
        uint yuan;
        uint jf;
};

#endif