#include "selfString.h"
#include <iostream>
#include <cstring>



namespace self
{
self::String::String(const char *str)
{
    if(NULL == str)
    {
        m_data = new char[1];
        *m_data = '\0';
    }
    else
    {
        int length = std::strlen(str);
        m_data = new char[length+1];
        std::strcpy(m_data,str);

    }
}

self::String::~String()
{
    delete[] m_data;

}

//*拷贝构造函数也是构造函数，传递的参数是等号右边的数
self::String::String(const String &other) //参数是本类型的引用
{
    int length = std::strlen(other.m_data);
    m_data = new char[length + 1];
    std::strcpy(m_data,other.m_data);
}

self::String& self::String::operator=(const String& other)
{
    //1.自赋值的检查
    if(this == &other)
    {
        return *this;
    }

    //2.删除原来占有的数据
    delete[] m_data;

    int length = std::strlen(other.m_data);
    m_data = new char[length+1];
    std::strcpy(m_data,other.m_data);

    return *this;
}

self::String& self::String::operator=(const char *other)
{
    delete[] m_data;
    
    if(other == NULL)
    {
        m_data = new char[1];
        *m_data = '\0';
    }
    else
    {
        int length = std::strlen(other);
        m_data = new char[length + 1];
        std::strcpy(m_data,other);

    return *this;
    }
}

}