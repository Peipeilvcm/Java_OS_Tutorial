#ifndef STRING_H_SELF
#define STRING_H_SELF
#include<iostream>

namespace self
{
    class String
    {
        public:
            String(const char * = NULL);
            ~String();
            //*拷贝构造函数
            String(const String&);

            //String a; a = b会调用下面这个函数
            String& operator=(const String &);//重载赋值运算符

            //String a; a = "hello";会调用下面这个函数
            String& operator=(const char *);//不同的输入参数不同的运算符函数

            inline const char* data() const
            {
                return m_data;
            }
        private:
            char *m_data;
    };
}

#endif