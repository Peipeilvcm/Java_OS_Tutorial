#include "selfString.h"
#include <iostream>

using namespace::std;
using namespace::self;

int main(int argc,const char *argv[])
{
    String s1("hello");

    String s2 = s1;
    String s3 = "world";

    s3 = s1;
    s3 = "world";

    cout << "s3= " << s3.data() << endl;
    return 0;
}