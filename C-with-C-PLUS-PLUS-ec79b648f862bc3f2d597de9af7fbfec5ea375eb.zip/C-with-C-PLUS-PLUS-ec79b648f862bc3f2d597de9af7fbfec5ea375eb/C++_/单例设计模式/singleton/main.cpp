#include "singleton.h"
#include <iostream>
using namespace::std;


int main(int argc, char *argv[])
{
    //*这样可以不用创建对象而直接调用函数
    Singleton::getInstance()->doSomething();

//*这样实例化就会出错，因为对象的构造函数和析构函数都是私有的
  //  Singleton* val = new Singleton();
    return 0;
}