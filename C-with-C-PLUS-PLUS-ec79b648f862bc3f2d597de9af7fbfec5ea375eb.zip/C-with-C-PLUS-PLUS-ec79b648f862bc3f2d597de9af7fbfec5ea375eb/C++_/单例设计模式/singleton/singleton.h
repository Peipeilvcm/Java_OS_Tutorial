#ifndef _SINGLETON_H
#define _SINGLETON_H

class Singleton
{
    public:
    //*这里必须使用static静态类型才可以在主函数中被调用
    //调用这个函数不会访问或者修改任何对象（非static）数据成员
    //类的静态成员(变量和方法)属于类本身，在类加载的时候就会分配内存，可以通过类名直接去访问；非静态成员（变量和方法）属于类的对象，所以只有在类的对象产生（创建类的实例）时才会分配内存，然后通过类的对象（实例）去访问
        static Singleton* getInstance();//*获得句柄才能操控这个对象
        void doSomething();
        void destroy();//资源的释放
    private:
        Singleton();//构造函数和析构函数都声明成私有的
        ~Singleton();

        Singleton(const Singleton&);//拷贝构造函数
        Singleton& operator=(const Singleton&);//赋值运算符

        static Singleton* instance; //句柄
};


#endif