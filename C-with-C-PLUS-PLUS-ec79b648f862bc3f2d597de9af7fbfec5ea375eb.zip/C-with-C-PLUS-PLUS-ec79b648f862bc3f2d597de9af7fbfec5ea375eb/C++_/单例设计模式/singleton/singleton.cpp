#include "singleton.h"

#include <iostream>
using namespace::std;

Singleton* Singleton::instance = NULL;//*类的静态成员需要在外部先进行初始化的声明

//构造函数
Singleton::Singleton()
{
    cout << "Singleton instance" << endl;
}

//析构函数
Singleton::~Singleton()
{

}

//*这个函数在多线程中是不安全的，需要加锁
Singleton* Singleton::getInstance()
{
    Singleton* ret = instance;
    if(instance == NULL)
    {
        instance = new Singleton();//*生成一个新的对象，给instance这个句柄指针
        ret = instance;
    }

    return ret;
}

void Singleton::doSomething()
{
    cout << __func__ << endl;
    cout << __LINE__ << endl;
}

void Singleton::destroy()
{
    delete this;
    instance = NULL;
}