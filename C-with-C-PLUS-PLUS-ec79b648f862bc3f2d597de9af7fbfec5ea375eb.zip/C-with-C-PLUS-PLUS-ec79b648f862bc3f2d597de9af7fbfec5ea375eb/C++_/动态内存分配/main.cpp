#include <iostream>

using namespace::std;

class Test
{
    public:
        Test()
            :m_value(0)   //初始化成员列表
        {
            cout << "test" << endl;
        }

        ~Test()
        {
            cout << "~test" << endl;
        }

    private:
        int m_value;
};

int main()
{
    {  //类的生命周期在{}中
        Test a;
    }
    cout << "end of }" << endl;

    Test *pVal = new Test(); //在堆上，会调用类的构造函数
    delete pVal;
    pVal = NULL;//编程规范，释放堆上的数据后指针指向NULL

    Test *pArray = new Test[2];
    delete[] pArray;

    return 0;
}