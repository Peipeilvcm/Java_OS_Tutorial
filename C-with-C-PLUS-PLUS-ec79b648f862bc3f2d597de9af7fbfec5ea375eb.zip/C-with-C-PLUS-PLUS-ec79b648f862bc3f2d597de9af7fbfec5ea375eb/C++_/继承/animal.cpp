#include "animal.h"

#include <iostream>

using namespace::std;

namespace keji300
{
    Animal::Animal(int age)
        :m_age(age)
    {
        cout << "Animal constructing" << endl;
    }

    Animal::~Animal()
    {
        cout << "Animal destructing" << endl;
    }

    int Animal::getAge() const
    {
        return m_age;
    }

    void Animal::setAge(int age)
    {
        m_age = age;
    }

    Cat::Cat(int age,int color)
        :Animal(age),m_color(color) //*让父类去初始化父类，基类初始化基类
    {
        cout << "Cat constructing" << endl;
    }

    Cat::~Cat()
    {
        cout << "Cat destructing " << endl;
    }

    int Cat::getColor() const
    {
        return m_color;
    }

    void Cat::setColor(int color)
    {
        m_color = color;
    }
}