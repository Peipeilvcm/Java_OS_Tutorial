#ifndef _CAR_H
#define _CAR_H
#include <cstring>
#include <iostream>
using namespace::std;


namespace keji300
{
    class Engine
    {
        public:
            Engine(int id)
                :m_id(id)
            {

            }
            ~Engine(){}

            void start()
            {
                cout << "engine start\n";
            }

            void stop()
            {
                cout << "engine stop\n";
            }

        private:
            int m_id;
    };

    class Wheel
    {
        public:
            Wheel(int id)
            {
                m_id = id;
            }
            ~Wheel() {}

            void roll()
            {
                cout << "wheel roll" << endl;
            }

        private:
            int m_id;
    };
    
        class Car
        {
            public:
                Car(Engine *,Wheel *,string name,int price);
                ~Car() {}

                void run();
                void stop();

            private:
                Car(const Car&);
                Car& operator=(const Car&);//把拷贝构造函数和赋值运算符写在私有域中达到禁止拷贝构造的作用
                Engine *engine;//声明一个对象指针
                Wheel *wheel;
                string name;
                int price;
        };

    class Stero
    {
        public:
            Stero() {}
            ~Stero() {}

            void play()
            {
                cout << "stero play" <<endl; 
            }
    };


    class Benchi : public Car
    {
        public:
            Benchi(Engine *,Wheel *,string,int,Stero *);
            ~Benchi() {}

            void musicOn();
        private:
            Stero *stero;


    };

    class Transformer : public Car
    {
        public:
            Transformer(Engine *,Wheel *,string,int,bool);
            ~Transformer() {}

            void fight();
            void transform();
        private:
            bool val;
    };

}


#endif