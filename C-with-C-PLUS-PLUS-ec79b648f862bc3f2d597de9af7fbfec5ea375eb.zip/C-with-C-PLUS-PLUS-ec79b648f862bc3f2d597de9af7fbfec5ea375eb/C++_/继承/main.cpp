#include "animal.h"
#include <iostream>
#include <cstring>
using namespace::keji300;

int main()
{
    Cat cat(1,1);
    int age =  cat.getAge();
    std::cout << "age is " << age << '\n';
    cat.setAge(2);
    cat.setColor(3);
    return 0;
}
