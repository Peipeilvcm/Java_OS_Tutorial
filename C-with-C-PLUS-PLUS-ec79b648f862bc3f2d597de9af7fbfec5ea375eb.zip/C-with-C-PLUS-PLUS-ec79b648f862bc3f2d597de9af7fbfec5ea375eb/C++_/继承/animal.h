#ifndef _ANIMAL_H
#define _ANIMAL_H
#include <string>
using namespace::std;
namespace keji300
{
    class Animal
    {
        public:
            Animal(int age);
            ~Animal();
            
            void setAge(int age);
            int getAge() const;
        private:
            int m_age;
        protected:
            string m_location;
        
    };

    class Cat : public Animal
    {
        public:
            Cat(int age,int color);
            ~Cat();

            int getColor() const;
            void setColor(int color);

        private:
            int m_color;
    };

    class Dog : public Animal
    {
        public:
            Dog();
            ~Dog();

            int setWeight();
            void getWeight(int weight);

        private:
            int m_weight;
    };
}


#endif