#ifndef _FRUIT_H
#define _FRUIT_H

class Fruit
{
    public:
        virtual ~Fruit() = 0; //接口类
        virtual void plant() = 0;
        virtual void grow() = 0;
        virtual void harvest() = 0;

};

class Apple : public Fruit
{
    public:
        Apple();
        ~Apple();

        void plant();
        void grow();
        void harvest();
};

class Grape : public Fruit
{
    public:
        Grape();
        ~Grape();
        void plant();
        void grow();
        void harvest();
};

enum
{
    APPLE = 0,
    GRAPE = 1
};

class Gardener
{
    public:
        Gardener();
        ~Gardener() {}
        // 0 apple; 1 grape
         Fruit* getFruit(int );

    private:
        Apple *apple;
        Grape *grape;
};

#endif