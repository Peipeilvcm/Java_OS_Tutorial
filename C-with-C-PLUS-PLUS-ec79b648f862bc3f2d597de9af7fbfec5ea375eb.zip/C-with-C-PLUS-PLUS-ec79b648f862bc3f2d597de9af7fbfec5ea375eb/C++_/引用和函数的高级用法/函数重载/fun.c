int foo(char ch,int val)
{
    return 0;
}