#ifndef _FUNC_H_
#define _FUNC_H_

#ifdef __cplusplus  //告诉c++编译器这段是c语言的调用，不需要重载
extern "C" {
#endif

int foo(char,int);

#ifdef __cplusplus
}
#endif

#endif


