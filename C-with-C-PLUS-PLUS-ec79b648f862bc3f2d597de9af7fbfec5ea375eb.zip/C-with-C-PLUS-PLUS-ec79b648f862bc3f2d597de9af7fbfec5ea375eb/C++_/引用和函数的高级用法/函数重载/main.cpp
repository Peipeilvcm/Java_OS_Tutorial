#include <iostream>
#include "fun.h"
#include <stdio.h>

int main(int argc,char *argv[])
{
    char ch = '0';
    int val = 0;
    foo(ch,val);
    printf("ssss");
    return 0;
}
