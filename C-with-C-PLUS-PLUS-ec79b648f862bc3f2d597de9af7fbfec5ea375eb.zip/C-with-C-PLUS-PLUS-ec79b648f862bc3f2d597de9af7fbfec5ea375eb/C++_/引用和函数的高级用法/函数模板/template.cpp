#include <iostream>
using namespace::std;

template<typename T> //函数模板参数类型和返回值类型

T abs(T x)
{
    return x<0?-x:x; //绝对值实现
}

int main()
{
    int n = -5;
    double d = -5.5;
    cout<<abs(n)<<endl;
    cout<<abs(d)<<endl;
    return 0;
}