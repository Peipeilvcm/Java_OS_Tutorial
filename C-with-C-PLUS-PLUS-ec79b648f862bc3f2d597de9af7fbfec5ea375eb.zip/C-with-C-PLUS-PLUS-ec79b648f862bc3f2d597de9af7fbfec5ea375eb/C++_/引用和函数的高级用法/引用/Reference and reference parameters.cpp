int intOne;

int& rint = intOne;
intOne = 5;

//输出都是5
cout<< "intOne: "<<int intOne<<endl;
cout<<"rint: "<<rint<<end1;


//输出都是7
rint = 7;
cout<<"intOne: "<<intOne<<endl;
cout<<"rint: "<<rint<<endl;