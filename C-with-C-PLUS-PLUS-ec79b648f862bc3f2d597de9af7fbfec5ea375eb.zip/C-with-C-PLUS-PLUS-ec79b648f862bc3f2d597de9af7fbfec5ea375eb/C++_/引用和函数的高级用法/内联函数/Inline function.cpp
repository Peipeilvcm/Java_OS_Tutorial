#include <iostream>
using namespace::std;

#include <stdio.h>

inline bool isnumber(char); //要先声明内联函数

inline bool isnumber(char c)
{
    return (ch>="0"&&ch<=9)?true:false;
}

int main(int argc,char *argv)
{
    char c;
    while((c=cin.get())!='\n')
    {
        if(isnumber(c))
            std::cout << "you entered a digit" << '\n';
        else
            std::cout << "you entered a non-digit" << '\n';
    }

    return 0;
}