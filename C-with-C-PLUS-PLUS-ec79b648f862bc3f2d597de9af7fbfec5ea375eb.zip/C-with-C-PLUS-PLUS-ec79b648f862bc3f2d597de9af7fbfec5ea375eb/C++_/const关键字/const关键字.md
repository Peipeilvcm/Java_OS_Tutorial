#### const 关键字
------
编码规范：不要使用具体的数字（Magic Number）
const使用：
1. const 指定了一个不该改变的对象
2. const 限定指针的类型：
const 出现在*的左边，表示被指物是常量
const 出现在*右边，表示指针自身是常量
```c
int main()
{
    const int a = 1;//后面就不能对a进行修改了
    int b = 0;
    const int *p = &a;//这里const修饰的是int，int定义的是整型值，因此*p所指向的对象值不能通过*p来修改，但是可以给p重新赋值使其指向不同的对象
    //*p = 1; 这里就会出错

    p = &b;//这样就可以
    p = &b;
}
```
```c
    int *const p2 = &b; //这里const修饰的p2,p2就不能指向其他的对象，但是*p2是可以赋不同的值的
```
------
const成员必须使用成员初始化列表进行初始化
```c
#include <iostream>

using namespace::std;

class A
{
    public:
        A();
        ~A() {}
    
    private:
        const int val;
}

A::A()
    :val(0)
{

}

int main()
{
    A a;
    return 0;
}
```
------
以const提高函数的健壮性
1. 用const引用替换值传递：节省了一次拷贝构造和析构的过程
```c
class Student
{
    public:
        Student(const char *pName = "NA",int ssId = 0); //构造函数
        ~Student(); //析构函数

        Student(const Student&);//*拷贝构造函数(用const表示不改变原来对象的值而只是传了一个引用过去)
}
```
2. 控制使用指针和引用传递的实参被以外修改

