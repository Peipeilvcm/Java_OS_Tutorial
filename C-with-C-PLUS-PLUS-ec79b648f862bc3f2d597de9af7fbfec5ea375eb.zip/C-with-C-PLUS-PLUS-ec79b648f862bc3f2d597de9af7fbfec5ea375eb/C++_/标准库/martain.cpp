#include <iostream>
#include "martain.h"

using namespace::std;

int Martain::martainCount = 0; //静态成员再类外分配空间和初始化

Martain::Martain()
{
    martainCount++; //构造函数实现计数增加
}

Martain::~Martain()
{
    martainCount--;
}

int Martain::getCount()
{
	return martainCount;
}

void Martain::fight()
{

}

void Martain::hide()
{

}