##### static类成员

尽量少使用全局变量

------

```cpp
class Martain
{
    public:
    	Martain(); //构造函数
    	~Martain();//析构函数
    
    	void fight();
    	void hide();
    	static int getCount(); //定义静态成员函数
   private:
    	static int martainCount;//定义类的静态成员
}
```

类成员函数的实现：

```cpp
Martain::Martain()
{
    martainCount++; //构造函数实现计数增加
}

Martain::~Martain()
{
    martainCount--;
}

int Martain::getCount()
{
	return martainCount;
}

int Martain::martainCount = 0; //静态成员再类外分配空间和初始化
```

------

static里面不能使用this指针，因为this指针是对象的地址操作

即使没有实例化类的对象，static成员和成员函数依然可以使用

static成员的名字在类的作用域中，因此可以避免与其他类的成员或者全局对象的名字冲突

static可以实现封装，static成员可以是私有成员，而全局对象是不可以的

