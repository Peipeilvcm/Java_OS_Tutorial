#ifndef _MARTAIN_H
#define _MARTAIN_H

class Martain
{
    public:
        Martain(); //构造函数
        ~Martain();//析构函数

        void fight();
        void hide();
        static int getCount(); //定义静态成员函数
    private:
        static int martainCount;//定义类的静态成员
        int m_bloodValue;
};

#endif