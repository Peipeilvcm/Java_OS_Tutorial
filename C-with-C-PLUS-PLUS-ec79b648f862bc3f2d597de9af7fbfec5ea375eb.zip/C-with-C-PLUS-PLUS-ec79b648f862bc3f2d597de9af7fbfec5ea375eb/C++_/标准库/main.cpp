#include <iostream>
#include <string>
#include "martain.h"

using namespace::std;

void func()
{
    Martain c;
    int count  = Martain::getCount();
    cout << "func count is " << count << endl;
}
int main()
{
    int count = Martain::getCount();//这里采用静态成员函数是可以定义在类的外部的，不需要先实例化对象
    cout << "static count is" << count << endl;

    Martain a;
    count = Martain::getCount();
    cout << "new count is " << count << endl;
    
    func();
    count = Martain::getCount();
    cout << "count after func is " << count << endl;

    return 0;
}
