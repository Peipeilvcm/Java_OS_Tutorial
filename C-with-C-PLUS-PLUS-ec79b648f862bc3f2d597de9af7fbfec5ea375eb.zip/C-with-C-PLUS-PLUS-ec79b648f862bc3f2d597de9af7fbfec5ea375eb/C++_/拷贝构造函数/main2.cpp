#include <iostream>
using namespace::std;
#include <stdio.h>
#include "person.h"


int main(int argc,char *argv[])
{
    Person p("Joe");
    Person p3("tom");
    Person p2 = p; //*调用拷贝构造函数
    p.print();
    p2.print();
    return 0;
}