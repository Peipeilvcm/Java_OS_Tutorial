#ifndef _PERSON_H
#define _PERSON_H

class Person
{
    public:
        Person(char *pName);
        ~Person();

        Person(const Person &s);
        Person& operator=(const Person& other);//赋值运算符，当一个对象=另一个对象时被调用
        
        void print();

    private:
        char *name;


};

#endif