#include <iostream>
using namespace::std;
#include <stdio.h>
#include "student.h"

void foo(Student stu)
{
    cout << "In fun" << __func__ << endl;
    printf("&stu = %x",&stu);

}

Student bar()  //*返回值是这个对象得时候也会调用拷贝构造函数
{
    Student tom("tom",112);
    return tom;
}

int main(int argc,char *argv[])
{
    cout << "Enter main----->\n";
    Student joe("Joe",111); //会调用构造函数

    Student john = joe;//*这个时候会调用拷贝构造函数（通过一个对象定义另一个对象）

    cout << "Calling foo" << endl;
    printf("joe = %x\n",&joe);
    foo(joe); //*这时候传递得函数参数得副本是这个对象，也会调用拷贝构造函数 把joe得副本传过去而不是joe本身
    cout << "After call of foo" << endl;

    Student tom = bar();
}