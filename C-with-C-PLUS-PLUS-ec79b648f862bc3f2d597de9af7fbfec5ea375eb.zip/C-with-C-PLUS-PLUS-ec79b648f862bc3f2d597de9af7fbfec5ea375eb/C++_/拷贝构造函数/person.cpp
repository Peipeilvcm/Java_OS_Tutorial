#include <iostream>
using namespace::std;
#include <stdio.h>
#include "person.h"
#include <cstring>  //相当与c语言得string.h


Person::Person(char *pN)
{
    if(pN!=NULL)
    {
        cout << "Constructing" << pN << endl;
        int len = strlen(pN) + 1;
        name = new char[len];
        cout << "name = " << static_cast<void *>(name) << endl;//强制转换
        memset(name,0,len);
        strcpy(name,pN);
    }
    else
    {
        name = NULL;
    }
}

Person::~Person()
{
    cout << "Destructing Person------>" << "\n" << endl;
    if(name!=NULL)
    {
        print();
        delete []name;
        name = NULL;
    }
}

void Person::print()
{   
    //*打印pName的内存地址
    cout << "pName = " << static_cast<void *>(name) << endl;
}

Person::Person(const Person &p)
{
    cout << "copy constructor of Person" << endl;
    if(p.name!=NULL)
    {
        int len = strlen(p.name) + 1;
        name = new char[len];
        cout << "name = " << static_cast<void *>(name) << endl;
        memset(name,0,len);
        strcpy(name,p.name);
    }
    else
    {
        name = NULL;
    }
}
    Person& Person::operator=(const Person &other)
    {
        cout << "operator = " << endl;
        if(&other == this)
        {
            return *this;
        }

        if(name!=NULL)
        {
            delete []name;
            name = NULL;
        }

        if(other.name!=NULL)
        {
            int len = strlen(other.name) + 1;
            name = new char[len];
            memset(name,0,len);
            strcpy(name,other.name);
        }
        else
        {
            name = NULL;
        }
    }
    
