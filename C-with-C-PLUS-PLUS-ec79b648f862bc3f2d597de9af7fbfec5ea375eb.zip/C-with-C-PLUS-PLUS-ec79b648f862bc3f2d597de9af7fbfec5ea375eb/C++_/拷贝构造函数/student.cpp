#include <iostream>
using namespace::std;
#include <stdio.h>
#include "student.h"
#include <cstring>  //相当与c语言得string.h

Student::Student(const char *pName,int ssId)
    :id(ssId)
{
    memset(name,0,40);
    if(pName != NULL)
    {
        int len = strlen(pName);
        len = (len > 39)?39:len;
        strncpy(name,pName,len);

    }
    cout << "constructor of student:" << name << endl;
}

Student::~Student()
{
    cout << "destruct of student:" << name << endl;
}

void Student::print()
{
    cout << "student: " << name << endl;
}

//*拷贝构造函数
Student::Student(const Student &s)
{
    cout << "Construcing copy  " <<  endl;
    printf("&s = %x\n",&s);
    strcpy(name,"copy");
    strcat(name,s.name); //连接两个字符串
    id = s.id;
}
