#ifndef _STUDENT_H
#define _STUDENT_H

class Student
{
    public:
        Student(const char *pName = "NA",int ssId = 0); //构造函数
        ~Student(); //析构函数

        Student(const Student&);//*拷贝构造函数

        void print();
   
    private:
        char name[40];
        int id;

};

#endif