#ifndef _CAR_H_
#define _CAR_H

//类的定义
class Car
{
    public:
        Car(int price = 10000,int carNum = 0);
        void run(); //函数仅声明，定义放在外部
        void stop();
        void SetProperty(int price,int carNum);
        void print();

    private:
        int m_price;
        int m_carNum;

};



#endif 