#include <iostream>
#include "car.h"

using namespace::std;

///* 类的实现*/
Car::Car(int price,int carNum)
{
    SetProperty(price,carNum);
}

void Car::run()
{
    std::cout << "car run" << '\n';
}

void Car::stop()
{
    std::cout << "car stop" << '\n';
}

void Car::SetProperty(int price,int carNum)
{
    m_price = price;
    m_carNum = carNum;
}

void Car::print()
{
    std::cout << m_price << '\n';
     std::cout << m_carNum << '\n';
}