#ifndef _STUDENT_H
#define _STUDENT_H

class Student
{
    public:
        Student(int id,int score); //*构造函数的定义

       inline int getId()
       {
           return m_id;
       }
        void setId(int id)
        {
            m_id = id;
        }

        int getScore()
        {
            return m_score;
        }
        void setScore(int score)
        {
            m_score = score;
        }

    private:
        int m_id;
        int m_score;
};


#endif 