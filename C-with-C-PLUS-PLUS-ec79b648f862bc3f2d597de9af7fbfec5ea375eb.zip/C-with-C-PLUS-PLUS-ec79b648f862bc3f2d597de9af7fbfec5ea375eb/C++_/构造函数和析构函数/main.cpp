#include <iostream>
#include "car.h"

using namespace::std;


int main()
{
    Car a;
    a.print();
    
    

    return 0;
}