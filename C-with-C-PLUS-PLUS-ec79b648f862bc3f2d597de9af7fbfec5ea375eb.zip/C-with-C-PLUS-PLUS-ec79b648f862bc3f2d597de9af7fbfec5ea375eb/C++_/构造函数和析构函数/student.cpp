#include <stdio.h>
#include "student.h"

using namespace::std;

Student::Student(int id,int score)
    :m_id(id),m_score(0)  //*初始化列表的方法
{

}
