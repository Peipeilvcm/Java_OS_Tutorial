#include <stdio.h>
#include <stdlib.h>

#definr N 10
typedef int data_t
//��ʽ�洢
//ͷ�ڵ�
typedef struct Node_head_t
{
	data_t data;
	struct Node_head_t *top;

}Head;

typedef struct Node_t
{
	data_t data;
	struct Node_t *next;

}Node;
//˳��洢
typedef struct Sqstack_t
{
	int top;//���������±�
	data_t data[N];//�����Ŀռ�
}sqstack;

//�п�
void EmptySqstack(sqstack *sq)
{
	
	if (sq->top == -1)
	{
		printf("the stack is empty\n");
	}
	
}
//����
void FullSqstack(sqstack *sq)
{
	if (sq->top == N-1)
	{
		printf("the stack is full\n");
	}
}

int main()
{
	sqstack *sq;
	sq = (sqstack *)malloc(sizeof(sqstack));


}