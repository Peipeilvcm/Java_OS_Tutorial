/*************************************************************************
> File Name: tree.c
> Author: WeiY
> Mail: weiyang_nj@farsight.com.cn
> Created Time: Sat 28 Jul 2018 03:40:22 AM PDT
************************************************************************/

#include<stdio.h>
#include <stdlib.h>

typedef char bt_data_t;

//int num;//变量   服务于逻辑
//data_t num;  //数据  服务用于程序结果   
//方便移植,脚本语言没有变量类型

typedef struct node_tree
{
    bt_data_t data;
    struct node_tree *lchild;
    struct node_tree *rchild;
}tree;

tree *CreateTree(int i, char array[], int n)
{
    int j;
    tree *root = NULL;
    root = (tree *)malloc(sizeof(tree));
    if(root == NULL)
    {
        printf("create was failed\n");
        exit(-1);
    }
    //数据域
    if(array[i] == '\0')
    {
        exit(-1);
    }
    root->data = array[i];
    printf("array[%d] = %c\n", i, array[i]);
    //左孩子
    j = 2*i;
    if(j<=n && array[j] != '\0')
    {
        root->lchild = CreateTree(j, array, n);
    }
    else
    {
        root->lchild = NULL;   
    }
    //右孩子
    j = 2*i+1;
    if(j<=n && array[j] != '\0')
    {
        root->rchild = CreateTree(j, array, n);
    }
    else
    {
        root->rchild = NULL;    
    }
    return root;
}

//前序遍历
void PreOrder(tree *root)
{
	if (root == NULL)
	{
		return;
	}
	printf("%c\t", root->data);//打印A
	PreOrder(root->lchild);//递归调用以左子树为一棵树，B为根节点
	PreOrder(root->rchild);//右子树

}

//中序遍历
void InOrder(tree *root)
{
	if (root == NULL)
	{
		return;
	}
	InOrder(root->lchild);
	printf("%c\t", root->data);
	InOrder(root->rchild);

}

//后序遍历
void PosOrder(tree *root)
{
	if (root == NULL)
	{
		return;
	}
	PosOrder(root->lchild);
	PosOrder(root->rchild);
	printf("%c\t", root->data);


}


int main(int argc, char *argv[])
{

    tree *root = NULL;

    bt_data_t array[] = {0, 
                         'A',
                         'B',        'C',
                         'D','E',    0,  'F',
                         0,0,'G','H',0,0,'I'
                        };

    CreateTree(1, array, sizeof(array)/sizeof(bt_data_t)-1);   //第一个参数是标号，第二参数是数组，第三参数数组长度
    printf("\n");

	PreOrder(root);
	InOrder(root);
	PosOrder(root);

    return 0;
}
