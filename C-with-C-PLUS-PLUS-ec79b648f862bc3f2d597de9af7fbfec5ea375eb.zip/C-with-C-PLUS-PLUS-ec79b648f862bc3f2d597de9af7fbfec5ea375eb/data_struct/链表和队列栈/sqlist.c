/*************************************************************************
	> File Name: sqlist.c
	> Author: WeiY
	> Mail: weiyang_nj@farsight.com.cn
	> Created Time: Mon 23 Jul 2018 06:23:25 PM PDT
 ************************************************************************/

#include<stdio.h>
#include <stdlib.h>
#include <time.h>

#define OK 0
#define ERROR -1
#define N 10

typedef int data_t;

//逻辑结构的物理存储的实现
typedef struct sqlist_t
{
    data_t data[N];  //连续的空间
    int length;//实际的顺序存储结构的长度
}Sqlist;

Sqlist *CreateEmtpySqlist()
{
    Sqlist *sq = NULL;

    sq = (Sqlist *)malloc(sizeof(Sqlist));
    if(sq == NULL)
    {
        printf("create was failed\n");
        exit(-1);
    }
    sq->length = 0;
    return sq;
}

int SqlistEmtpy(Sqlist *sq)
{
    if(NULL == sq)
    {
        printf("the sqlist is not exist\n");
        return ERROR;
    }

    if(0 == sq->length)
    {
        return OK;
    }
    else
    {
        return ERROR;   
    }
}

int SqlistFull(Sqlist *sq)
{
    if(NULL == sq)
    {
        printf("the sqlist is not exist\n");
        return ERROR;
    }

    if(N == sq->length)
    {
        return OK;
    }
    else
    {
        return ERROR;   
    }
}

int GetElem(Sqlist *sq, int i, data_t *data)
{
    if(NULL == sq)
    {
        printf("the sqlist is not exist\n");
        return ERROR;
    }
    
    if(i<0 || i>=sq->length)
    {
        printf("the position is error\n");
        return ERROR;
    }
    else
    {
        *data = sq->data[i];
        //sq->data[i] = data;
    }

    return 0;
}

void printfSqlist(Sqlist *sq)
{

    int i ;
    for(i=0; i<sq->length;++i)
    {
        printf("%d\t", sq->data[i]);
    }
    printf("\n");
    return;
}

int DeleteElem(Sqlist *sq, int i, data_t *data)
{
    int k;
    if(NULL == sq)
    {
        printf("the sqlist is not exist\n");
        return ERROR;
    }

    if(OK == SqlistEmtpy(sq))
    {
        printf("the position is error\n");
        return ERROR;
    }

    if(i<0 || i>=sq->length)
    {
        printf("the position is error\n");
        return ERROR;
    }
    else
    {
        *data = sq->data[i];
        for(k=i; k<sq->length-1; k++)
        {
            sq->data[k] = sq->data[k+1];
        }
        sq->length--;
    }
}
//插入一个元素
int InsertElem(Sqlist* sq, int i, data_t *data)
{
	int k;
	if (NULL == sq)
	{
		printf("the sqlist is not exist\n");
		return ERROR;
	}
	if (OK == SqlistFull(sq))
	{
		printf("error\n");
		return ERROR;

	}
	if (i < 0 || i>sq->length + 1)
	{
		printf("the position is error\n");
		return ERROR;
	}
	else if (i == sq->length + 1)
	{
		sq->data[i] = *data;
	}
	else
	{
		
		
		for (k = sq->length-1; k>=i; --k)
		{
			sq->data[k + 1] = sq->data[k];
		}
		sq->data[i] = *data;
		sq->length++;
	}

}

int main(int argc, char *argv[])
{
    int i;
    Sqlist *sq = NULL;
    data_t data_in = 5;
    
    srand(time(NULL));
    sq = CreateEmtpySqlist();
    
    for(i=0; i<N-3; ++i)
    {
        sq->data[i] = rand()%100 + 1;
        sq->length++;
    }
    
    //printfSqlsit(sq);

    //GetElem(sq, 5, &data);

    //printf("GetElem = %d\n", data);

    //DeleteElem(sq, 1, &data);
    //printfSqlsit(sq);
    //printf("DeleteElem = %d\n", data);
	printfSqlist(sq);

	InsertElem(sq, 0, &data_in);

	printfSqlist(sq);


    return 0;
}
