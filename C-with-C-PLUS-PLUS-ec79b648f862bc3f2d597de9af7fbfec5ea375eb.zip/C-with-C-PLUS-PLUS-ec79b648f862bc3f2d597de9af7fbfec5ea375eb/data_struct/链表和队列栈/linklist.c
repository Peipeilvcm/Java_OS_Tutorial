#include<stdio.h>
#include <stdlib.h>
#include <time.h>

#define OK 0
#define ERROR -1

typedef int data_t;


typedef struct node_t
{
    data_t data;      //实际的数据域
    struct node_t *next;  //管理地址的指针域
}Node;

Node *CreateEmptyLinkList()
{
    Node *ls = NULL;
    ls = (Node *)malloc(sizeof(Node));
    if(ls == NULL)
    {
        printf("create was failed\n");
        exit(ERROR);
    }
    ls->next = NULL; //判断链表是否为空的标准
    return ls;
}

//创建整个链表
int HeadInsert(Node *ls, int n)
{
    Node *nd = NULL;
    int i;
    srand(time(NULL));
    if(NULL == ls)
    {
        printf("the linklist is not exist\n");
        exit(ERROR);
    }

    for(i=0; i<n; ++i)
    {
        nd = (Node *)malloc(sizeof(Node));
        if(NULL == nd)
        {
            printf("create position was error\n");
            exit(-1);
        }

        nd->data = rand()%100 + 1;
        nd->next = ls->next;
        ls->next = nd;
    }

    return OK; 
}

int TailInsert(Node *ls, int n)
{
    int i;
    Node *s = NULL;   //遍历工作
    Node *nd = NULL;  //生成新的节点
    srand(time(NULL));
    s = ls;
    if(NULL == ls)
    {
        printf("the linklist is not exist\n");
        exit(ERROR);
    }
    for(i=0; i<n; ++i)
    {
        nd = (Node *)malloc(sizeof(Node));
        if(NULL == nd)
        {
            printf("create position was error\n");
            exit(-1);
        }

        nd->data = rand()%100 + 1;
        s->next = nd;
        s = s->next; //跑指针操作都是这句话
    }
    s->next = NULL;
    return OK;
}

int GetLinkListElem(Node *ls, int i, data_t *data)
{
    Node *s = NULL;
    int j;
    s = ls;
    j = 0;

    if(NULL == ls)
    {
        printf("the linklist is not exist\n");
        exit(ERROR);
    }

    while(s && j<i)
    {
        s = s->next;
        j++;
    }

    if(!s)
    {
        printf("the position is error\n");
        return ERROR;
    }

    *data = s->data;  //查询
    //s->data = data;  //修改

    return OK;
}

int InsertLinkList(Node *ls, int i, data_t data)   //
{
    int j;
    Node *nd = NULL;
    Node *s = NULL;
    s = ls;
    j = 1;

    if(NULL == ls)
    {
        printf("the linklist is not exist\n");
        exit(ERROR);
    }

    while(s && j<i)
    {
        s = s->next;
        j++;
    }

    if(!s)
    {
        printf("the position is error\n");
        return ERROR;
    }

    nd = (Node *)malloc(sizeof(Node));
    if(NULL == nd)
    {
        printf("create position was error\n");
        exit(-1);
    }
    
    nd->data = data;
    nd->next = s->next;
    s->next = nd;

    return OK;
}

int DeleteLinkList(Node *ls, int i)   //按位置删除
{
	int j;
	Node *nd = NULL;
	Node *s = NULL;
	s = ls;
	j = 0;

	if (NULL == ls)
	{
		printf("the linklist is not exist\n");
		exit(ERROR);
	}

	while (s->next && j<i-1)
	{
		s = s->next;
		j++;
	}

	if (!s)
	{
		printf("the position is error\n");
		return ERROR;
	}

	Node *p = NULL;
	p = s->next;
	s->next = p->next;
	free(p);
	p = NULL;
	

	return OK;
}

void PrintLinkList(Node *ls)
{
    Node *s = NULL;
    s = ls->next;     //负责遍历工作
    while(s)   //s == NULL 0为假   s！= NULL  非0值，非0为真
    {
        printf("%d\t", s->data);
        s = s->next;
    }
    printf("\n");
    return;
}

//链表的倒置
void Reverselist(Node* ls)
{
	int j;

	Node *s = NULL;
	Node *p = NULL;
	s = ls->next;
	ls->next = NULL;



	while (s)
	{
		
		p = s;
		s = s->next;

		p->next = ls->next;
		ls->next = p;
		
	
	}
	
}
//相邻最大和
Node *Max_Adjacentlist_and(Node *ls)
{
	Node *s = NULL;//跑路指针
	Node *p = NULL;//记录最大值的节点
	p = s;
	s = ls->next;
	int m1;
	if (!s->next)
	{
		printf("only 1 node\n");
		return NULL;
	}
	int m0 = s->data + s->next->data;
	if (NULL == ls)
	{
		printf("the linklist is not exist\n");
		exit(-1);
	}

	if(NULL == ls->next)
	{
		printf("empty list\n");
		return NULL;
	}
	while (s->next->next)
	{
		s = s->next;
		m1= s->data + s->next->data;
		if (m0 < m1)
		{
			m0 = m1;
			p = s;
		}
	}
	return p;
}
//
//void Max_Adjacentlist_and(Node *ls,int* Max_data)
//{
//	int j;
//	int Max_data_temp[1000];
//	int Max_data_t;
//
//	Node *s = NULL;
//	Node *p = NULL;
//	s = ls->next;
//	p = s->next;
//	
//	for ( j=0;j<14;j++)
//	{
//		Max_data_temp[j] = s->data + p->data;
//		s = s->next;
//		p = s->next;
//
//	}
//	
//	Max_data_t = Max_data_temp[0];
//	for (int i = 0; Max_data_temp[i] != 0; i++)
//	{
//		if (Max_data_temp[i] > Max_data_t)
//		{
//			Max_data_t = Max_data_temp[i];
//		}
//	}
//	for (int k = 0; Max_data_temp[k] != 0; k++)
//	{
//		printf(" Max_data_temp is %d\n", Max_data_temp[k]);
//	}
//	
//	*Max_data = Max_data_t;

//}

int main(int argc, char *argv[])
{
    Node *ls = NULL;
    data_t data = 0;
	int Max_data;
    ls = CreateEmptyLinkList();
    //HeadInsert(ls, 15);
    TailInsert(ls,15);
 /*   PrintLinkList(ls);
    GetLinkListElem(ls, 0, &data);
    printf("GetElem = %d\n", data);
    InsertLinkList(ls,7,109);*/
 /*   PrintLinkList(ls);*/
	/*DeleteLinkList(ls, 5);*/
	/*Reverselist(ls);*/
	PrintLinkList(ls);
	//Max_Adjacentlist_and(ls,&Max_data);
	//printf("max_data is %d\n", Max_data);

    return 0;
}
