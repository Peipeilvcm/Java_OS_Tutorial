#include <stdio.h>
#include <stdlib.h>

typedef struct TwoPhreadTree_t
{
	char data;
	struct TwoPhreadTree_t *lchild;
	struct TwoPhreadTree_t *rchild;
}twotree;

void Createtree(int i,char a[],int length) //��ţ����鳤�ȣ����鳤��
{
	int j;
	twotree *root = NULL;
	root = (twotree *)malloc(sizeof(twotree));
	if (root == NULL)
	{
		printf("create failure\n");
		exit(-1);
	}

	//������
	if (a[i] == '\0');
	{
		exit(-1);
	}
	root->data = a[i];

	//����
	j = 2 * i;
	if (j <= length && a[j] != '\0')
	{
		root->lchild = Createtree(j, a, length);
	}
	else
	{
		root->lchild = NULL;
	}
	//�Һ���
	j = 2 * i + 1;
	if (j <= length && a[j] != '\0')
	{
		root->rchild = Createtree(j, a,length);
	}
	else
	{
		root->rchild = NULL;
	}

	return root;
}

int main()
{
	twotree *root = NULL;

	


	return 0;
}