/*************************************************************************
	> File Name: qiuzhong.c
	> Author: WeiY
	> Mail: weiyang_nj@farsight.com.cn
	> Created Time: Fri 27 Jul 2018 08:40:04 PM PDT
 ************************************************************************/

#include<stdio.h>

#define ONE_MIN 5
#define FIVE_MIN 12
#define ONE_HOUR 12
#define BALLQUE 28

typedef int data_t;
 
//栈的结构
typedef struct Sqstack_t
{
    data_t *data;    
    int top;
}stack;

//队列结构
typedef struct SqQueue_t
{
    data_t *data;
    int front;
    int rear;
}

stack *CreateEmptyStack(int length)
{
    stack *sk = NULL;
    sk = (stack *)malloc(sizeof(stack));
    if(sk == NULL)
    {
        printf("create was failed\n");
        exit(-1);
    }

    sk->data = (data_t *)malloc(sizeof(data_t)*length);//可变空间大小
    if(sk->data == NULL)
    {
        printf("create was failed\n");
    }

    sk->top = -1;
    return sk;
}

int main(int argc, char *argv[])
{
    int i;
    data_t data;
    stack *one_min = CreateEmptyStack(5);
    stack *five_min = CreateEmptyStack(12);
    stack *one_hour = CreateEmptyStack(12);
    queue *ballque = CreateEmptyQueue(28);

    //装好28个球
    for(i=1; i<=BALLQUE-1; ++i)
    {
        EnQueue(ballque, i);
    }
    while(1)
    {
        DeQueue(ballque, &data);
        PushStack(one_min, data);
        if(FullStack（one_min）)
        {
            for(4)
            {
                PopStack(one_min, );
                EnQueue();
            }
            PushStack(five_min, PopStack());
        }
        if(FullStack（five_min）)
        {
            for(11)
            {
                EnQueue(ballque, data_t PopStack(five_min, ));
            }
            PushStack(one_hour, PopStack(five_min))
        }
        if(FullStack（one_hour）)
        {
            for(12)
            {
                PopStack(one_min, );
                EnQueue();
            }
        }
        ShowTime(one_min, five_min, one_hour);
        sleep(1);
    }
    return 0;
}
