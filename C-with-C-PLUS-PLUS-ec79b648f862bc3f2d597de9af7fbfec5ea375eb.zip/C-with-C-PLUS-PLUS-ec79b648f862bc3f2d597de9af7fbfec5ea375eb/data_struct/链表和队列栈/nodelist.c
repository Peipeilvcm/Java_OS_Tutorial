#include<stdio.h>
#include<stdlib.h>
#include<time.h>

typedef int data_t;

typedef struct node_t
{
	data_t data;
	struct node_t *next;
}Node;

//����ͷ�ڵ� ����һ���ձ� �˷�һ���ڵ���Ϊ��ͷ
Node* CreateHeadNode()
{
	Node *ls = NULL;
	ls = (Node *)malloc(sizeof(Node));
	if (ls == NULL)
	{
		printf("create error\n");
		exit(-1);
	}
	ls->next = NULL;//����Ϊ��
	return ls;
}

//������������
int HeadInsert(Node *ls,int n)
{
	int i;
	srand(time(NULL));
	Node *nd = NULL;
	if (NULL == ls)
	{
		printf("the linklist is not exist\n");
		exit(-1);
	}
	for (i = 0; i < n; ++i)
	{
		nd = (Node *)malloc(sizeof(Node));//Ҫ����Ľڵ�
		if (nd == NULL)
		{
			printf(" create point error\n" );
			exit(-1);

		}
		nd->data = rand() % 100 + 1;
		//�������(�����ȶ�ͷָ��)
		nd->next = ls->next;
		ls->next = nd;
	}
	return 0;
}

//β�巨��������
int TailInsert(Node *ls, int n)
{
	srand(time(NULL));
	Node *s = NULL;//��ʱָ��,������ָ��
	Node *nd = NULL;//����Ľڵ�

	s = ls;//s����ͷλ��
	if (NULL == ls)
	{
		printf("the linklist is not exist\n");
		exit(-1);
	}
	for (int i = 0; i < n; ++i)
	{
		nd = (Node *)malloc(sizeof(Node));//Ҫ����Ľڵ�
		if (nd == NULL)
		{
			printf(" create point error\n");
			exit(-1);

		}
		nd->data = rand() % 100 + 1;
		s->next = nd;
		s = s->next;//��ָ�����

	}
	s->next = NULL;





	return 0;
}

//��������
int PrintLinklist(Node *ls)
{
	Node *s = NULL;
	s = ls->next;
	while (s!=NULL)
	{
		printf("%d\t", s->data);
		s = s->next;
	}
	printf("\n");
	return 0;
}

//��λ�ò�ѯ
int GetElem(Node *ls,int i,data_t *data)
{
	Node *s = NULL;
	s = ls;
	int j;
	if (NULL == ls)
	{
		printf("error\n");
		exit(-1);
	}
	while (s&&j<i)
	{
		s = s->next;
		j++;
	}
	if (!s)
	{
		printf("the position is error\n");
		return -1;
	}
	*data = s->data;
	//�޸�
	//s->data = *data;

	return 0;
}

//������Ԫ��
int InsertLinkList(Node* ls, int i, data_t data)
{
	Node *nd = NULL;
	int j;
	Node *s = NULL;
	s = ls;
	if (NULL == ls)
	{
		printf("the linklist is not exist\n");
		exit(-1);
	}
	//nd->next = ls->next;
	//ls->next = nd;
	while (s&&j < i - 1)
	{
		s = s->next;
		j++;
	}
	if (!s)
	{
		printf("the position is error\n");
		return -1;
	}
	nd->data = data;
	nd->next = s->next;
	s->next = nd;
	return 0;
}

int main()
{
	Node *ls = NULL;
	ls = CreateHeadNode();
	data_t  data ;

//	HeadInsert(ls, 15);
	TailInsert(ls, 15);

	PrintLinklist(ls);

	//GetElem(ls, 1, &data);

	//printf("getelem = %d\n", data);
	InsertLinkList(ls, 5, 55);

	return 0;
}
