#include<stdio.h>
#include<stdlib.h>

#define N 10
#define OK 0
#define ERROR -1

typedef int data_t;

typedef struct Sqlist_t
{
	data_t data[N];
	int length;
}Sqlist;

//�����յ�˳��洢�ṹ
Sqlist* CreateEmtpySqlist()
{
	Sqlist *sq = NULL;
	sq = (Sqlist*)malloc(sizeof(Sqlist));
	if (sq == NULL)
	{
		printf("create is failed\n");
		exit(-1);
	}
	sq->length = 0;
	return sq;
}

//�жϱ��Ƿ�Ϊ��
int SqlistEmpty(Sqlist *sq)
{
	if (NULL == sq)
	{
		printf("the sqlist is not exist\n");
		return ERROR;
	}
	if (sq->length == 0)
	{
		return OK;
	}
	else
	{
		return ERROR;
	}
}

//�ж��Ƿ���
void SqlistFull(Sqlist *sq)
{
	if (NULL == sq)
	{
		printf("the sqlist is not exist\n");
		return ERROR;
	}
	if (sq->length == N)
	{
		return OK;
	}
	else
	{
		return ERROR;
	}
}

//��ȡһ��Ԫ�ص�ֵ
int GetElem(Sqlist* sq,int i,data_t *data)
{
	if (NULL == sq)
	{
		printf("the sqlist is not exist\n");
		return ERROR;
	}
	if (i < 0 || i >= sq->length)
	{
		printf("the position is error\n");
		return ERROR;
	}

	if (i < sq->length)
	{
		*data = sq->data[i];

	}
	return 0;
}

void printfSqlist(Sqlist* sq)
{

		for(int i=0;i<sq->length;i++)
		{
			printf("%d\t", sq->data[i]);
		}
	
}

//ɾ��һ��Ԫ��
void DeleteElem(Sqlist* sq,int i,data_t *data)
{
	int k;
	if (NULL == sq)
	{
		printf("the sqlist is not exist\n");
		return ERROR;
	}
	if (1 == SqlistEmpty(sq))
	{
		printf("error\n");
		return ERROR;

	}
	if (i < 0 || i >= sq->length)
	{
		printf("the position is error\n");
		return ERROR;
	}
	else
	{
		*data = sq->data[i];
		for (k=i;k<sq->length-1;k++)
		{
			sq->data[k] = sq->data[k + 1];
		}
		sq->length - 1;
	}
}

//����һ��Ԫ��
InsertElem(Sqlist* sq,int i,data_t *data)
{
	int k;
	if (NULL == sq)
	{
		printf("the sqlist is not exist\n");
		return ERROR;
	}
	if (OK == SqlistFull(sq))
	{
		printf("error\n");
		return ERROR;

	}
	if (i < 0 || i>sq->length+1)
	{
		printf("the position is error\n");
		return ERROR;
	}
	else if (i == sq->length + 1)
	{
		sq->data[i] = *data;
	}
	else
	{
		sq->data[i] = *data;
		for (k = sq->length; k>i; k--)
		{
			sq->data[k+1] = sq->data[k];
		}
		sq->length + 1;
	}

}

int main()
{
	Sqlist *sq = NULL;

	data_t data;

	data_t data_in = 5;

	sq = CreateEmtpySqlist();

	for (int i = 0; i < N; ++i)
	{
		sq->data[i] = rand() % 10 + 1;
		sq->length++;
	}

	//GetElem(sq, 5, &data);

	printfSqlist(sq);

	InsertElem(sq, 5, &data_in);

	printfSqlist(sq);

	//DeleteElem(sq, 9, &data);

	//printf("deletelem = %d\n", sq->data[9]);


	return 0;

}