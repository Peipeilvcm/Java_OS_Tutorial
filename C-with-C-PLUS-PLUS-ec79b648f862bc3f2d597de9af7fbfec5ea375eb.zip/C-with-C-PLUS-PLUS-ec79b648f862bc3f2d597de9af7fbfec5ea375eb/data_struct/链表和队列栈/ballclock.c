#include <stdio.h>
#include <stdlib.h>

#define QINITSIZE 28
#define QElemType int
#define OK 0
#define ERROR -1
#define BALLQUE 28

//���еĴ���
typedef struct QueueType 
{
	QElemType *data;
    int front;
	int rear;

}queue;

queue *CreateEmptyqueue(int length)
{
	queue *qu = NULL;
	qu = (queue *)malloc(sizeof(queue));
		if (qu == NULL)
		{
			printf("create is failure\n");
			exit(ERROR);
		}

	qu->data = (QElemType *)malloc(sizeof(QElemType)*length);//�ɱ�ռ��С������
	if (qu->data == NULL)
	{
		printf("create is failure\n");
		exit(ERROR);
	}

	qu->front = qu->rear = 0;

	return qu;
}

//�����
void Enqueue(queue *qu, int value)
{
	if ((qu->rear + 1) % 28 == qu->front)//˳�������ʱ��
	{
		printf("the queue is full\n");
	}
	else
	{
		qu->rear = (qu->rear + 1) % 28;
		qu->data[qu->rear] = value;
		
	}
}

//������
int Dequeue(queue *qu)
{
	int data;
	if (qu->rear == qu->front)
	{
		printf("the queue is empty\n");
		exit(ERROR);
	}
	else
	{
		/*printf("%d\n", qu->data[qu->front]);*/
		
		data = qu->data[qu->front];
	/*	printf("the data1 is %d\t", data);*/
		qu->front = (qu->front + 1) % 28;

	}
	return data;
}


//ջ����
typedef struct Sqstack_t
{
	QElemType *data;
	int top;
	
}stack;

stack *CreateEmptystack(int length)
{
	stack *sk = NULL;
	sk = (stack *)malloc(sizeof(stack));
	if (sk == NULL)
		{
			printf("create is failure\n");
			exit(ERROR);
		}

	sk->data = (QElemType *)malloc(sizeof(QElemType)*length);//�ɱ�ռ��С������
	if (sk->data == NULL)
		{
			printf("create is failure\n");
			exit(ERROR);
		}

	sk->top = -1;
	return sk;
}



//ѹջ
void PushStack_4(stack *sk, int data)
{
	if (sk->top == 4)//ջ��
	{
		printf("the stack is full\n");
	}
	else
	{
		sk->data[sk->top] == data;
		sk->top = sk->top + 1;
	}
}

void PushStack_12(stack *sk, int data)
{
	if (sk->top == 11)//ջ��
	{
		printf("the stack is full\n");
		exit(ERROR);
	}
	else
	{
		sk->top = sk->top + 1;
		sk->data[sk->top] == data;
	}
}


//��ջ
int PopStack(stack *sk, int *data)
{
	int data1;
	if (sk->top == -1)//�ж�ջ��
	{
		printf("the stack is empty\n");
		exit(ERROR);
	}
	else
	{
		data1 = sk->data[sk->top];
		*data = sk->data[sk->top];
		sk->top = sk->top - 1;
	}
	return data1;;
}

//��ʾʱ��
void ShowTime(stack *one_min, stack *five_min, stack *hour_min)
{
	printf("the time is hour:%d\t min:%d\t sec:%d\n", (hour_min->top)+1, (five_min->top)+1, (one_min->top))+1;
}


int main()
{
	
	stack *one_min = CreateEmptystack(5);//һ����ջ
	stack *five_min = CreateEmptystack(12);
	stack *hour_min = CreateEmptystack(12);
	queue *ballque = CreateEmptyqueue(28);
	int i, j, k;
	int data;
	int *data2;
	int temp;
	int data3;

	//��28����

	
	for (i = 1; i <= BALLQUE - 1; ++i)
	{
		Enqueue(ballque, i);//�����
	/*	printf("the queue is %d\t", ballque->data[i]);*/
	}
	
	while (1)
	{
		
		data = Dequeue(ballque); //����
		printf("the data is %d\t", data);
		PushStack_4(one_min, data);//ѹջ
		printf("the one_min top is %d\t", one_min->top);
	
		if (one_min->top ==4) //
		{
			for (i=0;i<4;++i)
			{
				PopStack(one_min, data2);//��one_minute�е����ݵ����ص�������
				Enqueue(ballque,*data2);
			}
			PushStack_12(five_min,PopStack(one_min, &temp));//��ʣ�µ����һ�����ݴ�one_min������ѹ�뵽five_min��
		}
		if (five_min->top == 11)
		{
			for (j=0;j<11;++j)
			{
				Enqueue(ballque,PopStack(five_min,&temp));
			}
			PushStack_12(hour_min, PopStack(five_min, &temp));
		}
		if (hour_min->top == 11)
		{
			for (k=0;k<12;++k)
			{
				PopStack(one_min,&data3);
				Enqueue(ballque,data3);
			}
		}

		ShowTime(one_min, five_min, hour_min);
		sleep(1);
	}

	return 0;
}

