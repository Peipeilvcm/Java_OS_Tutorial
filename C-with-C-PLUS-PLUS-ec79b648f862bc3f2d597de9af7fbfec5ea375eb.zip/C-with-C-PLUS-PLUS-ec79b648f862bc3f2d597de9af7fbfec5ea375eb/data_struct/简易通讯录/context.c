#include<stdio.h>
#include<stdlib.h>
#include<string>

#define MAXLEN 10
#define OK 0
#define ERROR -1

typedef struct node
{
	char name;
	char  sex;
	int number;
	char note[MAXLEN];
	struct node *next;
}AddressNode;
typedef struct node *AddressList;

//����ͷ�ڵ�
AddressList CreateEmptyLinkList()
{
	AddressList L = NULL;
	L = (AddressList)malloc(sizeof(AddressNode));
	if (L == NULL)
	{
		printf("create was failed\n");
		exit(ERROR);
	}
	L->next = NULL; //�ж������Ƿ�Ϊ�յı�׼
	return L;
}

//������ʼ��
AddressList InitListWithData(AddressList L)
{
	char *name_table[] = { "tidder","lili","peter","tom","jerry" };
	char *sex_table[] = { "boy","girl","boy","girl","boy" };
	int num_table[] = { 123,789,345,455,512 };

	AddressList nd = NULL;
	int i = 0;
	if (NULL == L)
	{
		printf("the context is not exist\n");
		exit(ERROR);
	}
	for (i = 0; i <5; ++i)
	{
		nd = (AddressList)malloc(sizeof(AddressNode));
		if (NULL == nd)
		{
			printf("create addresslist is failure\n");
			exit(ERROR);
		}
		nd->name[10] = *name_table[i];
		nd->sex[10] = *sex_table[i];
		nd->number = num_table[i];

		nd->next = L->next;
		L->next = nd;

	}
	return OK;


}

//��ӡ����
void PrintAddressNode(AddressList L)
{
	AddressList s = NULL;
	s = L->next;
	while (s)
	{
		printf("name is %s\t,sex is %s\t,number is %d\n ",s->name,s->sex,s->number);
		s = s->next;
	}

	printf("\n");
}

//�������
void ClearList(AddressList L)
{
	AddressList s = NULL;
	AddressList p = NULL;

	s = L->next;
	while (s)
	{
		p = s;
		s = s->next;
		free(p);
		p = NULL;
	}
	L->next = NULL;
}

int main()
{
	AddressList L = NULL;
	L = CreateEmptyLinkList();
	InitListWithData(L);
	PrintAddressNode(L);
	ClearList(L);
	PrintAddressNode(L);

	return 0;
}