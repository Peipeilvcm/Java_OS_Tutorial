#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include<string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include<pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <time.h>
#include <sys/mman.h>
#include<signal.h>
#include <sys/socket.h>
#include <errno.h>
#include<netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sqlite3.h>